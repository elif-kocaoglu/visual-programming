﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
namespace tekstil_final_projesi
{
    public partial class detaylı_bilgi : Form
    {
        public detaylı_bilgi()
        {
            InitializeComponent();
           
        }
        public MySqlConnection conn = new MySqlConnection("Server=127.0.0.1;Database=tekstil;Uid=root;Pwd='';");//formun veri tabanına giriş yapması için her açtığımda gidiyo burdan alırım

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void detaylı_bilgi_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("C:\\indir.jfif");// fotoraf ekleme kodu diğerleri olmiy ve bu yaptığım pc den çekme yerel disk c den çekiyorum öbür türlüsünü beceremedim başka bulursam denicem
            
            //veri tabanından istediğim bilgileri çekmek için
            MySqlCommand cmd;
            MySqlDataReader dr;

            cmd = new MySqlCommand();
            string sorgu = "Select adı from erkek WHERE id = 1";
            string deger;
            MySqlCommand komut = new MySqlCommand(sorgu, conn);
            conn.Open();
            deger = (string)komut.ExecuteScalar();
            conn.Close();
            label2.Text = deger;

            string sorgu2 = "Select renk from erkek WHERE id = 1";
            string deger2;
            MySqlCommand komut2 = new MySqlCommand(sorgu2, conn);
            conn.Open();
            deger2 = (string)komut2.ExecuteScalar();
            conn.Close();
            label3.Text = deger2;

            string sorgu3 = "Select fiyat from erkek WHERE id = 1";
            string deger3;
            MySqlCommand komut3 = new MySqlCommand(sorgu3, conn);
            conn.Open();
            deger3 = (string)komut3.ExecuteScalar();
            conn.Close();
            label4.Text = deger3;

            string sorgu4 = "Select beden from erkek WHERE id = 1";
            string deger4;
            MySqlCommand komut4 = new MySqlCommand(sorgu4, conn);
            conn.Open();
            deger4 = (string)komut4.ExecuteScalar();
            conn.Close();
            label5.Text = deger4;

            /*  conn.Open();
              cmd.Connection = conn;
              cmd.CommandText = "SELECT adı FROM erkek WHERE id = 1"; // burda sql sorgumu yazdım erkek tablosundan ad olanı ve id si 1 olanı çağrdım
              dr = cmd.ExecuteReader();
              while (dr.Read())
              {
                  listBox1.Items.Add(dr["adı"]);
              }
              conn.Close();// burda kapatmam lazım alandan dolayı

              conn.Open(); // burdada tekrar aynı işemleri yaptım sadece çağırdığım verinin adını değiştim gerisi aynı
              cmd.Connection = conn;
              cmd.CommandText = "SELECT renk FROM erkek WHERE id = 1";
              dr = cmd.ExecuteReader();
              while (dr.Read())
              {
                  listBox2.Items.Add(dr["renk"]);
              }

              conn.Close();
              conn.Open();
              cmd.Connection = conn;
              cmd.CommandText = "SELECT fiyat FROM erkek WHERE id = 1";
              dr = cmd.ExecuteReader();
              while (dr.Read()) //buradan emin değilim araştır
              {
                  listBox3.Items.Add(dr["fiyat"]);
              }
              conn.Close();
              conn.Open();
              cmd.Connection = conn;
              cmd.CommandText = "SELECT beden FROM erkek WHERE id = 1";
              dr = cmd.ExecuteReader();
              while (dr.Read())
              {
                  listBox4.Items.Add(dr["beden"]);
              }
              conn.Close();
                 */
        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 anasayfa=new Form1();
            anasayfa.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

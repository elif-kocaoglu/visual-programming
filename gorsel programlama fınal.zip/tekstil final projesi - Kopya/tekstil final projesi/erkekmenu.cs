﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace tekstil_final_projesi
{
    public partial class erkekmenu : Form
    {
        public erkekmenu() // araştır
        {
            InitializeComponent();// araştır
        }
        public MySqlConnection conn = new MySqlConnection("Server=127.0.0.1;Database=tekstil;Uid=root;Pwd='';");//formun veri tabanına giriş yapması için her açtığımda gidiyo burdan alırım
        private void erkekmenu_Load(object sender, EventArgs e)
        {
           
            pictureBox2.Image = Image.FromFile("C:\\indir.jfif");// fotoraf ekleme kodu diğerleri olmiy
            pictureBox3.Image = Image.FromFile("C:\\palto.jfif");
            pictureBox4.Image = Image.FromFile("C:\\an.jfif");
            pictureBox5.Image = Image.FromFile("C:\\lol.png");

        }

        private void aNASAYFAToolStripMenuItem_Click(object sender, EventArgs e) // açıklamayı yazamadım araştır
        {
            Form1 anasayfa = new Form1();
            anasayfa.Show();// formu gösterme
            this.Hide();// formu gizleme
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            detaylı_bilgi detaylı=new detaylı_bilgi();
            detaylı.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            detaylı_bilgi detaylı = new detaylı_bilgi();
            detaylı.Show();
            this.Hide();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            detaylıbilgi3 detaylıbilgi3=new detaylıbilgi3();
            detaylıbilgi3.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            detaylıbilgi2 detaylıbilgi2 = new detaylıbilgi2();
            detaylıbilgi2.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            detaylıbilgi2 detaylıbilgi2 = new detaylıbilgi2();
            detaylıbilgi2.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            detaylıbilgi3 detaylıbilgi3 = new detaylıbilgi3();
            detaylıbilgi3.Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            detaylıbilgi4 detaylıbilgi4= new detaylıbilgi4();
            detaylıbilgi4.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            detaylıbilgi4 detaylıbilgi4 = new detaylıbilgi4();
            detaylıbilgi4.Show();
            this.Hide();
        }

    }
    
}

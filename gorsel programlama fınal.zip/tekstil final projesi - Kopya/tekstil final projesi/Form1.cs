﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace tekstil_final_projesi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public MySqlConnection conn = new MySqlConnection("Server=127.0.0.1;Database=tekstil;Uid=root;Pwd='';");//formun veri tabanına giriş yapması için her açtığımda gidiyo burdan alırım

        private void erkekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            erkekmenu erkekmenu=new erkekmenu();
            erkekmenu.Show();
            this.Hide();
        }

        private void kADINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kadınmenü kadınmenü = new kadınmenü();
            kadınmenü.Show();
            this.Hide();
        }
    }
}

﻿namespace tekstil_final_projesi
{
    partial class detaylıbilgi3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(detaylıbilgi3));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aNASAYFAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.erkekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kADINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çOCUKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bEBEKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gİRİŞToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.üYEGİRİŞİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEPETİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gray;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aNASAYFAToolStripMenuItem,
            this.erkekToolStripMenuItem,
            this.kADINToolStripMenuItem,
            this.çOCUKToolStripMenuItem,
            this.bEBEKToolStripMenuItem,
            this.gİRİŞToolStripMenuItem,
            this.üYEGİRİŞİToolStripMenuItem,
            this.sEPETİMToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(616, 28);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aNASAYFAToolStripMenuItem
            // 
            this.aNASAYFAToolStripMenuItem.Name = "aNASAYFAToolStripMenuItem";
            this.aNASAYFAToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.aNASAYFAToolStripMenuItem.Text = "ANA SAYFA";
            // 
            // erkekToolStripMenuItem
            // 
            this.erkekToolStripMenuItem.Name = "erkekToolStripMenuItem";
            this.erkekToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.erkekToolStripMenuItem.Text = "ERKEK";
            // 
            // kADINToolStripMenuItem
            // 
            this.kADINToolStripMenuItem.Name = "kADINToolStripMenuItem";
            this.kADINToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.kADINToolStripMenuItem.Text = "KADIN";
            // 
            // çOCUKToolStripMenuItem
            // 
            this.çOCUKToolStripMenuItem.Name = "çOCUKToolStripMenuItem";
            this.çOCUKToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.çOCUKToolStripMenuItem.Text = "ÇOCUK";
            // 
            // bEBEKToolStripMenuItem
            // 
            this.bEBEKToolStripMenuItem.Name = "bEBEKToolStripMenuItem";
            this.bEBEKToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.bEBEKToolStripMenuItem.Text = "BEBEK";
            // 
            // gİRİŞToolStripMenuItem
            // 
            this.gİRİŞToolStripMenuItem.Name = "gİRİŞToolStripMenuItem";
            this.gİRİŞToolStripMenuItem.Size = new System.Drawing.Size(58, 24);
            this.gİRİŞToolStripMenuItem.Text = "GİRİŞ";
            // 
            // üYEGİRİŞİToolStripMenuItem
            // 
            this.üYEGİRİŞİToolStripMenuItem.Name = "üYEGİRİŞİToolStripMenuItem";
            this.üYEGİRİŞİToolStripMenuItem.Size = new System.Drawing.Size(92, 24);
            this.üYEGİRİŞİToolStripMenuItem.Text = "ÜYE GİRİŞİ";
            // 
            // sEPETİMToolStripMenuItem
            // 
            this.sEPETİMToolStripMenuItem.Name = "sEPETİMToolStripMenuItem";
            this.sEPETİMToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.sEPETİMToolStripMenuItem.Text = "SEPETİM";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(579, 363);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.NavajoWhite;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(353, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "ÜRÜN DETAYLARI";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(24, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(249, 344);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(313, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 27;
            this.label5.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(313, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(313, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(313, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "label2";
            // 
            // detaylıbilgi3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(616, 411);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "detaylıbilgi3";
            this.Text = "detaylıbilgi3";
            this.Load += new System.EventHandler(this.detaylıbilgi3_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aNASAYFAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem erkekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kADINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çOCUKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bEBEKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gİRİŞToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem üYEGİRİŞİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEPETİMToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}
-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 26 Ara 2022, 15:37:38
-- Sunucu sürümü: 8.0.28
-- PHP Sürümü: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `tekstil`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `erkek`
--

DROP TABLE IF EXISTS `erkek`;
CREATE TABLE IF NOT EXISTS `erkek` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adı` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `renk` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiyat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beden` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `açıklama` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `erkek`
--

INSERT INTO `erkek` (`id`, `adı`, `renk`, `fiyat`, `beden`, `açıklama`) VALUES
(1, 'Slim Fit Erkek Antrasit Mont', 'siyah', '1.200.00 TL', 'XL / L / S', 'Ürün Açıklaması\r\nFermuarlı cepli\r\nİki yandan cepli\r\nFermuar kapamalı\r\nSu geçirmez özellikli\r\nSoğuk kış günlerinde sizi sıcak tutar\r\nManken Bilgisi\r\nGöğüs: 102 cm Bel: 78 cm Basen: 100 cm Boy: 190 cm\r\nManken L beden ürün giyiyor.\r\n\r\nÜrün İçeriği ve Özellikleri\r\nÜrün İçeriği:\r\n1.Astar: %100 Polyester\r\n\r\n2.Astar: %100 Polyester\r\n\r\nDolgu: %100 Polyester\r\n\r\nKaplama: %100 Poliüretan\r\n\r\nZemin Kumaşı: %60 Polyester %40 VİSKOZ\r\n\r\nÜrün Özellikleri:\r\n\r\nCinsiyet: Erkek\r\n\r\nMarka: LCW Vision\r\n\r\nÜrün Tip: Deri Görünümlü Mont\r\n\r\nKalınlık: Kalın\r\n\r\nKalıp: Dar\r\n\r\nKol Boyu: Uzun Kol\r\n\r\nYaka: Dik Yaka\r\n\r\nDesen: Düz'),
(2, 'Haki Renk Italyan Kesim Pantolon \r\n', 'Haki', '429.99 TL', 'S / M / XS', ''),
(3, 'Erkek Sweatshirt Uzun Kollu', 'siyah', '987.00 TL', 'XL / M / S / XLL', ''),
(4, ' ERKEK KAPŞONLU SWEATSHİRT', 'Beyaz', '239.99 TL', 'XM / M / S / XLL', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
